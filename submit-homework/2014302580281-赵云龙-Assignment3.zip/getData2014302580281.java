package infoSpider;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
public class getData2014302580281 implements Runnable{
	public List<String> test=new ArrayList<>();
	public List<List<String>> lists=new ArrayList<>();
	public getData2014302580281() throws IOException
	{
	
		String url="http://cs.whu.edu.cn/plus/list.php?tid=36";
		Document menu=Jsoup.connect(url).get();
		Elements datas=menu.select("dd.j_name");
	    for(Element data:datas){
	    	//if not empty
	    	if(!data.select("a").text().equals("")){
	    		List<String> list=new ArrayList<>();	    		
	    		//get personal page's url
	    		String Turl="http://cs.whu.edu.cn/plus/"+data.select("a").attr("href");
	    		list.add(Turl);
	    		//System.out.println(Turl);
	    		//get name
	    		list.add(data.select("a").text());
	    		//System.out.println(data.select("a").text());
	    		//get field
	    		list.add(data.select("span.job_research").text());
	    		//System.out.println(data.select("span.job_research").text());
	    		//to the lists
	    		lists.add(list);
	    		
	    	}	
	    	}
	    //while(i<lists.size()-1){
		//	int n=getI();
		//	everyPage(n);
		//	}
	}
	private int i=-1;
	private static String getdetail(String input,String way)
    {
    	
    	Pattern pattern = Pattern.compile(way);

        Matcher matcher = pattern.matcher(input);

        if(matcher.find()){
        	return matcher.group(0);
        }

        return "-";
    }
	private void everyPage(int i)
	{
		System.out.println(i);
		String url=this.lists.get(i).get(0);
		Document teacher = null;
		try {
			teacher = Jsoup.connect(url).get();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element div=teacher.getElementById("container");
		//get phone
		String str=div.text();
		String phone;
		phone=getdetail(str,"(\\d|-)+");
		lists.get(i).add(phone);
		//get email
		String email;
		email=getdetail(str,"[a-zA-Z]+@[a-z.0-9]+");
		lists.get(i).add(email);
		//System.out.println(phone);
		//get detail
		//System.out.println(div.select("font").text());
		lists.get(i).add(div.select("font").text());
	}
	private synchronized int getI()
	{
		if(i<lists.size())i++;
		return i;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(i<lists.size()-1){
			int n=getI();
			everyPage(n);
			//System.out.println(lists.get(n).size());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
	}
}
