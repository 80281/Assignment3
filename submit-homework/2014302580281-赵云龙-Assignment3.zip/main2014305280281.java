package infoSpider;

import java.io.IOException;
import java.sql.SQLException;

public class main2014305280281 {
public static void main(String[]args) throws IOException, SQLException, InterruptedException
{
	//threads(5);
	threads(1);
}
private static void threads(int n) throws SQLException, InterruptedException
{
	
	insert2014302580281 ins=new insert2014302580281(n);
	
	int i=0;
	while(i<5){
		Thread threadsave=new Thread(ins);
		threadsave.start();
		i++;
		//System.out.println(i);
	}	
}
}

