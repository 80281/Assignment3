package infoSpider;
import java.io.IOException;
import java.sql.*;
import java.util.*;
public class insert2014302580281 implements Runnable{
	private getData2014302580281 data = null;
	private long startTime;
	static private long useTime;
	static private int numberOfThread;
	public insert2014302580281(int n)
	{	
		startTime=System.currentTimeMillis();
		try {
			data = new getData2014302580281();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(n!=0){
			Thread threadget=new Thread(data);		
			threadget.start();
			n--;
		}
		
		this.n=data.lists.size();
	}
	public void saveData(List<List<String>> list) throws SQLException
	{
		{
			String name=list.get(i).get(1);
			String email=list.get(i).get(4);
			String phone=list.get(i).get(3);
			String direct =list.get(i).get(2);
			String introduction=list.get(i).get(5);
			Connection conn = null;
			String sql;
	        String url = "jdbc:mysql://localhost:3306/test?"+"user=root&password=123456,&useUnicode=true&characterEncoding=UTF8";	 
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	            conn = DriverManager.getConnection(url);
	            Statement stmt = conn.createStatement();
	     	    System.out.println("创建数据表成功");
	            sql = "insert into test values('"+name+"', '"+email+"', '"+ phone +"', ' "+direct +"', '"+introduction+"')";
	            stmt.executeUpdate(sql);
	            
	        } catch (SQLException e) {
	            System.out.println("MySQL操作错误");
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            conn.close();
	        }
	 
	    }
	 
	}
	public long pusetime()
	{
		//System.out.println(useTime);
		return useTime;
	}
	private int i=0;
	private int n;
	//private List<List<String>> lists=new ArrayList<>();
	@Override
	public synchronized void run() {
		System.out.println("begin");
		numberOfThread++;
		// TODO Auto-generated method stub
		while(i<n){			
			
			try {
				System.out.println(numberOfThread+""+data.lists.get(i));//不知道为什么不print这个就不对
				//System.out.println(data.lists.size());
				//System.out.println("insert"+data.lists.get(i).size());
				
				if(data.lists.get(i).size()==6){
					saveData(data.lists);
					System.out.println("save");
					i++;
					System.out.println(i);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("线程耗时："+(System.currentTimeMillis()-startTime)+"ns");
	}
}

